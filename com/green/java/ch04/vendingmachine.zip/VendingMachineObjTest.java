package com.green.java.ch04.vendingmachine;

public class VendingMachineObjTest {
    public static void main(String[] args) {
        VendingMachineObj vm = new VendingMachineObj();
        Drink cola = new Drink ("");
        vm.insert(10_000);
        vm.insert(10_000);
        vm.insert(10_000);

        vm.showMenus();
        vm.showMoney();
    }
}
