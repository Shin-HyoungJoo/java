package com.green.java.ch04.vendingmachine;

import java.util.ArrayList;
import java.util.List;

public class VendingMachineObj {
    private int money;
    private List<Drink> list = new ArrayList<>();

    public void insert(int money) {
        this.money += money;
    }

    public void showMoney() {
        System.out.println("money : " + money);
    }

//    public void purchase(int money) {
//        this.money -= money;
//    }
}
